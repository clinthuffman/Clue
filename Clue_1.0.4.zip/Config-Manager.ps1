param()
# This code is Copyright (c) 2016 Microsoft Corporation.
#
# All rights reserved.
#
# THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
# �INCLUDING BUT NOT LIMITED To THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.'
#
# IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
# �CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
#  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
# �WITH THE USE OR PERFORMANCE OF THIS CODE OR INFORMATION.

$Error.Clear()
Remove-Module * -Force
Import-Module .\Modules\General.psm1 -Force
Import-Module .\Modules\Xml.psm1 -Force
Import-Module .\Modules\FileSystem.psm1 -Force
Import-Module .\Modules\TaskScheduler.psm1 -Force

[string] $Log = '.\Config-Manager.log'
$null = Remove-Item -Path $Log -Force -ErrorAction SilentlyContinue
[datetime] $dtLastLogTruncate = (Get-Date)

$error.Clear()
Write-Log ('Start Log') -Log $Log
Write-Log ('Written by Clint Huffman (clinth@microsoft.com)') -Log $Log

Function Import-Requests
{
    param([string] $NewConfigFilePath, [string] $ConfigFilePath)

    #// Open config.xml
    [xml] $XmlDocConfig = Get-Content -Path $ConfigFilePath -Force -ErrorAction SilentlyContinue
    Test-Error -Err $Error -Log $Log
    if (Test-Property -InputObject $XmlDocConfig -Name 'Configuration' -Log $Log)
    {
        [System.Xml.XmlElement] $XmlConfig = $XmlDocConfig.Configuration
    }

    [xml] $XmlDocNewConfig = Get-Content -Path $NewConfigFilePath -Force -ErrorAction SilentlyContinue
    Test-Error -Err $Error -Log $Log
    if (Test-Property -InputObject $XmlDocNewConfig -Name 'CLUE' -Log $Log)
    {
        [System.Xml.XmlElement] $XmlNewConfig = $XmlDocNewConfig.CLUE
    }

    $XmlConfig
    $XmlNewConfig
}

#// Create Clue folder in %Public%
[string] $sClueChangesFolderPath = $(Get-Content env:PUBLIC) + '\Documents\Clue'
if ((Test-Path -Path $sClueChangesFolderPath) -eq $false)
{
    $null = New-Item -Path $sClueChangesFolderPath -ItemType Directory -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    if ((Test-Path -Path $sClueChangesFolderPath) -eq $false)
    {
        Write-Log ('Unable to create "' + $sClueChangesFolderPath + '"!!! Exiting !!!')
        Exit;
    }
}

#// Create NewConfig.xml
[string] $sNewConfigFilePath = $sClueChangesFolderPath + '\NewConfig.xml'
if ((Test-Path -Path $sNewConfigFilePath) -eq $false)
{
    Add-Content -Path $sNewConfigFilePath -Encoding Unicode -Value '<CLUE></CLUE>' -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    if ((Test-Path -Path $sNewConfigFilePath) -eq $false)
    {
        Write-Log ('Unable to create "' + $sNewConfigFilePath + '"!!! Exiting !!!')
        Exit;
    }
}

[bool] $global:IsChanged = $false

$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = $sClueChangesFolderPath
$watcher.IncludeSubdirectories = $false
$watcher.EnableRaisingEvents = $true
$Changed = Register-ObjectEvent $watcher "Changed" -Action {
    [string] $FullPath = $eventArgs.FullPath
    if ($FullPath.IndexOf('NewConfig.xml') -ge 0)
    {        
        [bool] $global:IsChanged = $true
    }
}

[string] $sConfigFilePath = $(Get-Content env:PROGRAMDATA) + '\Clue\config.xml'

do
{
    if ($global:IsChanged -eq $true)
    {
        Write-Log ('IsChanged: ' + $IsChanged.ToString()) -Log $Log
        $global:IsChanged = $false
        Import-Requests -ConfigFilePath $sConfigFilePath -NewConfigFilePath $sNewConfigFilePath
    }
    Start-Sleep -Seconds 1
} until ($true -eq $false)

Write-Host ('Done!')
Exit;
